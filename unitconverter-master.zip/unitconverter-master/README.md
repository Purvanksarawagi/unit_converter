# unitconverter
Python+Tkinter unit converter tool

Requires python3.

* __unitcalc.py__:

Contains a dicitionary of quantities (e.g Length, Temperature) with units and lambda expressions for conversion between units.

* __unitcalcgui.py__

GUI implementation in tkinter
